#!/usr/bin/sh
rm -rf ~/.local/share/Trash/*
